document.addEventListener('DOMContentLoaded', function() {
    const draggableItems = document.querySelectorAll('.draggable-item');
    const dropZones = document.querySelectorAll('.drop-zone');
    const menuToggle = document.getElementById('menuToggle');
    const dropdownMenu = document.getElementById('dropdownMenu');

    menuToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        dropdownMenu.classList.toggle('show');
    });

    document.addEventListener('click', function() {
        dropdownMenu.classList.remove('show');
    });

    dropdownMenu.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    dropZones.forEach(zone => {
        const content = document.createElement('div');
        content.className = 'drop-zone-content';
        zone.appendChild(content);
    });

    draggableItems.forEach(item => {
        item.addEventListener('dragstart', function(e) {
            e.dataTransfer.effectAllowed = 'copy';
            e.dataTransfer.setData('text/html', this.innerHTML);
            e.dataTransfer.setData('type', this.dataset.type);
            this.classList.add('dragging');
        });

        item.addEventListener('dragend', function() {
            this.classList.remove('dragging');
        });
    });

    dropZones.forEach(zone => {
        zone.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
            this.classList.add('drag-over');
        });

        zone.addEventListener('dragleave', function() {
            this.classList.remove('drag-over');
        });

        zone.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('drag-over');

            const type = e.dataTransfer.getData('type');
            const html = e.dataTransfer.getData('text/html');
            
            const droppedItem = document.createElement('div');
            droppedItem.className = 'dropped-item';
            droppedItem.innerHTML = html;
            droppedItem.dataset.type = type;
            
            const removeBtn = document.createElement('span');
            removeBtn.className = 'remove-btn';
            removeBtn.innerHTML = '×';
            removeBtn.onclick = function() {
                droppedItem.remove();
            };
            
            droppedItem.appendChild(removeBtn);

            const contentArea = this.querySelector('.drop-zone-content');
            contentArea.appendChild(droppedItem);
        });
    });
});

function clearAllRooms() {
    const dropZoneContents = document.querySelectorAll('.drop-zone-content');
    dropZoneContents.forEach(content => {
        content.innerHTML = '';
    });
    closeMenu();
}

function resetLayout() {
    clearAllRooms();
    closeMenu();
}

function showHelp() {
    alert('How to use:\n\n1. Drag items from the left sidebar\n2. Drop them into the room zones\n3. Click the × button to remove items\n4. Use the menu to clear rooms or reset');
    closeMenu();
}

function showAbout() {
    alert('Drag and Drop Room Designer\n\nA simple room arrangement tool\nCreated by Jerald Jhon Maca\nSystem Integration 2 Project');
    closeMenu();
}

function closeMenu() {
    document.getElementById('dropdownMenu').classList.remove('show');
}
